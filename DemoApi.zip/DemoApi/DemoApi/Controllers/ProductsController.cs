﻿using Microsoft.AspNetCore.Mvc;
using DemoApi.Data;
using DemoApi.Models;

namespace DemoApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly DemoApiDbContext _context;

        public ProductsController(DemoApiDbContext context)
        {
            _context = context;
        }

        // GET: api/products
        [HttpGet]
        public IActionResult GetProducts()
        { 
            var products = _context.Products.ToList();
            return Ok(products);
        }

        //GET: api/products/1
        [HttpGet("{id}")]
        public IActionResult GetProduct(int id)
        {
            var product = _context.Products.Find(id);
            if (product == null) return NotFound();
            return Ok(product);
        }

        //POST: api/products
        [HttpPost]
        public IActionResult CreateProduct(Product product)
        { 
            _context.Products.Add(product);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetProduct), new { id = product.Id }, product);
        }

        //PUT: api/products/1
        [HttpPut("{id}")]
        public IActionResult UpdateProduct(int id, Product Product)
        {
            if (id != Product.Id) return BadRequest();

            var existingProduct = _context.Products.Find(id);
            if (existingProduct == null) return NotFound();

            existingProduct.Name = Product.Name;
            existingProduct.Price = Product.Price;

            _context.SaveChanges();
            return Ok(existingProduct);
        }

        // PATCH: api/products/1
        [HttpPatch("{id}")]
        public IActionResult UpdateProductPartial(int id, [FromBody] Product product)
        {
            var existingProduct = _context.Products.Find(id);
            if (existingProduct == null) return NotFound();

            if (!string.IsNullOrEmpty(product.Name))
                existingProduct.Name = product.Name;

            if (product.Price > 0)
                existingProduct.Price = product.Price;

            _context.SaveChanges();
            return Ok(existingProduct);
        }

        //DELETE: api/products/1
        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int id)
        {
            var product = _context.Products.Find(id);
            if (product == null) return NotFound();

            _context.Products.Remove(product);
            _context.SaveChanges();
            return NoContent();
        }
    }
}
